
/**
 * Write a description of class mod3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class mod3
{
    public static void main (String Args [])
    {
        new mod3 ();
    }

    public mod3 ()
    {
        int binary = IBIO.inputInt ("Enter a binary number (max 8 bits): ");
        int bin1 = binary%10;
        int bin2 = ((binary%100)/10)*2;
        int bin3 = ((binary%1000)/100)*4;
        int bin4 = ((binary%10000)/1000)*8;
        int bin5 = ((binary%100000)/10000)*16;
        int bin6 = ((binary%1000000)/100000)*32;
        int bin7 = ((binary%10000000)/1000000)*64;
        int bin8 = ((binary%100000000)/10000000)*128;
        int decimal = bin1 + bin2 + bin3 + bin4 + bin5 + bin6 + bin7 + bin8;
        System.out.println ("Okay, that's "+decimal+" in decimal.");
        int num = IBIO.inputInt ("\nEnter an integer (between 0-255): ");
        int num1 = num/128;
        int num2 = (num%128)/64;
        int num3 = ((num%128)%64)/32;
        int num4 = (((num%128)%64)%32)/16;
        int num5 = ((((num%128)%64)%32)%16)/8;
        int num6 = (((((num%128)%64)%32)%16)%8)/4;
        int num7 = ((((((num%128)%64)%32)%16)%8)%4)/2;
        int num8 = (((((((num%128)%64)%32)%16)%8)%4)%2)/1;
        System.out.println ("Cool, that's "+num1+" "+num2+" "+num3+" "+num4+" "+num5+" "+num6+" "+num7+" "+num8+" in binary!");

    }
}    